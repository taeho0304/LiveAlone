-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 3.38.97.229    Database: live_alone
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `is_manger` bit(1) DEFAULT NULL,
  `user_email` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_pass` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_phone` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `estate_info_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1qx06s5eu43btbqhl1nqbl1v4` (`estate_info_id`),
  CONSTRAINT `FK1qx06s5eu43btbqhl1nqbl1v4` FOREIGN KEY (`estate_info_id`) REFERENCES `estate_info` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,NULL,'','asdf','','$2a$10$EeUe5F/vFaQeHMbaeo8C.OcmUMbmRK/W4naunzGSCvZXyYOBKKB0O','',NULL),(2,NULL,'ssafy@ssafy.com','ssafy','강민주','$2a$10$ZIkgP69Vu3s3J.VJ0OjnAOE13OOAeOny6IFfDsUNJixMvtSRRl9fG','010-1234-5678',1),(4,NULL,'ddddf@naver.com','test','배태호','$2a$10$.9bhlQzlt0CXaUJf/kY80eaoqZEV6miHMwUdP0RZoebDYySdYpNHC','010-1234-5678',NULL),(5,NULL,'pkjeogus@gmail.com','bong','봉대현','$2a$10$2kba2rJ1QV8h1MTM6bB..e2inZu3uPaQfvFSSzogWAGIHZAv5gqv.','010-1234-5789',NULL),(6,NULL,'qwer@naver.com','1','변준형','$2a$10$avi5z1RwHnm0zsZReto2S..rDsmsGx.4tlrolQh0lMNrtWZZzGIMW','010-1111-1111',NULL),(7,NULL,'pkjeogus@gmail.com','bong1234','봉대현','$2a$10$Z4z4V9oI5QAAHKNH.tKf6elWh4RaoEJzhJ1vVzJgFXOOuDZ0Di/qi','010-1234-5678',NULL),(8,NULL,'pkjeogus@gmail.com','bong123','봉대현','$2a$10$ncsPmgcOmS7xyqchVoGmC.oNkVBQOu2LLLHyVsWUESECu0KORInKC','010-1234-5678',NULL),(11,NULL,'ssafy@gmail.com','ssafy1234','김사피','$2a$10$Qkr5fgQt4NEr3CbdiQ.Bx.xuI34PStt4.9frqLkPpTWgW4lYJyDXu','010-1212-1212',NULL),(12,NULL,'daebalprime@gmail.com','daebalprime','김대연','$2a$10$pTCLAVPTeT.6rTlMffTLtuEOspeh5M8j4p55iN/4QCSvIO/SJe6vu','010-1234-5678',NULL),(14,NULL,'ttest@ttest.ttest','ttest','ttest','$2a$10$b.15Jfs.r/CSuzPJGA07rePpsSyORm3SDiBfqiPqDdeyK/qR2riRm','010-1234-1234',5001),(15,NULL,'test@test.com','test123','test','$2a$10$wi4u0t6a19FP5CT4DjecXOkM4EfJ0ajXeVOWs/gHNsmvP0p0BuDYq','010-1234-1234',NULL),(16,NULL,'qhrud0527@naver.com','qjatn109','김범수','$2a$10$5AT5krEXPOdqSA6Whd/VX.RTnyR54cmNIzjUaq5JQ7Nr.8jGRrfYi','010-2339-7702',NULL),(17,NULL,'1@naver.com','2','2','$2a$10$WMlW.0M0uzTylxoOnsbyqOBn85asarNhkMp334zvhzFcwueQIXO3.','010-0000-0000',NULL),(18,NULL,'ssafy@naver.com','ssafy12345678','ssafy12345678','$2a$10$BEhhCZ9/YIyEsG4kEBjzveB.1zEtjFdNM6C7XP0GpjtVWmYhdZslm','010-1234-5678',NULL),(19,NULL,'r@r.com','r','r','$2a$10$miMZkJ8oOozatwZXGYmeSe2t32FZ2SGMnl20NksMgUdAh2YjSz4Ci','010-1010-0101',NULL),(20,NULL,'whduddn@whduddn.com','조영우','조영우','$2a$10$5FZhSde.up2OlArmkhXEPePla8rLowd09XGMWFDsH5EmBA.cftjmW','010-0000-0000',NULL),(21,NULL,'test1@naver','test1','ㅁㅁ','$2a$10$670taGNrC1M2hTfzd3EHf.XzCtuxCzhWt0E17CewaU0ImYAGlhgLq','010-1234-5678',NULL),(22,NULL,'dfdf@naver.com','ㅇㄹㅇㄹ','ㅇㄹㅇㄹ','$2a$10$KoNJjPOCyxDckNxnExk7dOvC5.cKnryLHHV7BFtJY8uG0E.SNW5aO','010-9999-9999',NULL),(23,NULL,'al@naver,com','alal','하하하','$2a$10$YgB0un.YtGdZfVywCQKKrOPL/3b8CG1Fym1PFh4hWAN.md3af5dzq','010-8311-7425',5001),(24,NULL,'asd@asd.co','asd','asd','$2a$10$nET45YS/4LR63S7rFRIPcec/mYR2PLbCms8M8uPDkKe4rW0sq9vhq','010-1223-1232',NULL),(25,NULL,'r@r.com','rc','r','$2a$10$ATkKcKpFIDCOtTsXMYk4k.tX13Xvz7EWbHYlyOfoytcHyxtI5pI9e','010-5000-1000',5001),(26,NULL,'test2@nanana','test2','111','$2a$10$OD3gvl85Pu/Jq8NivZ9FXeUEor.w4intRCiJLpPc7Ub1xGg5ZQrNe','010-1234-5678',5001),(27,NULL,'adf@gmail.com','mushroom','독버섯','$2a$10$MK.89lMOAaret3LjiOPtG.ZhlJro0BGSPCULDC6JNt83Io69ZVp.6','010-484-445',NULL),(30,NULL,'alswn@naver','alswn8972','강민주당당','$2a$10$hKxdEs3jRRBvFkNf4j4fMe7FkUqVZKM9WwlCikaR3tEaiXvKY5rzq','010-1234-5678',NULL),(31,NULL,'ykh1214@naver.com','Ftest','윤경한','$2a$10$dbQ0wBzZ.oScJc/7Tws4O.v6ATSHOhaghiVBtTjapVxbU.3qoX2DG','010-2459-3840',NULL),(32,NULL,'ssafy123@naver.com','ssafy111','김싸피','$2a$10$GSTHy91u3f7Ir9EswbksMOqSErni4LomcVzESL1UhHIxSBAS6mvfW','010-1234-1111',1),(33,NULL,'asdf@asdf.com','asdfasdf','asdf','$2a$10$P5oVO3ig3uASwe5gTa3A.ucom0hoThHUXv/DilmPQjzVpBDnCrah.','000-0000-0000',NULL),(34,NULL,'a@a.net','abcde','김김김','$2a$10$KoYoGyfZidM9T/0FymsBaesWs3v.z8eKAO4uuOiV8n/WD.MMMLYDq','01012345566',NULL),(35,NULL,'bjh2754@naver.com','bjh2754','변준형','$2a$10$FV25oQLs4dQtJs2YHTbfF.cDgF2KMD062Qz9hF228wjDR7CaOSCEW','010-3135-2754',NULL),(36,NULL,'asads@naver.com','asdasdasd','윤경한','$2a$10$H1If4IMojdPCavstWgFVEe0WTBkf0Os3/7qSZrD128iUDw/pa9rpS','010-2459-3840',NULL),(37,NULL,'a@g.co','ajsur2785','최윤','$2a$10$d9hdEG3RRkaxLWGjxnXHrecGbCzA3hcFg62E8nXcna9lUMjXzcRd6','010-1234-0000',NULL),(38,NULL,'asd@r.co','alive','마','$2a$10$CFv5cTy0w9gcoVkNFQMInufsLB7hFXRJK5ziALIFfJ8S54D0BznfK','010-15-4512',NULL),(39,NULL,'asd@g.com','alive2','변준형','$2a$10$HcIkBEp0E3oK4NkI6LJO5eZWDSVS3LE9j82Ky9xVReIxzj53zFrLy','010-1234-5642',60951);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-08  1:16:16
